package com.javatechie.solid.lsp.solution;

public interface PostMediaManager {

    public  void publishPost(Object post);
}
