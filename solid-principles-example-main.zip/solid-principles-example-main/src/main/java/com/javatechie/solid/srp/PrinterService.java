package com.javatechie.solid.srp;

public class PrinterService {

    public void printPassbook() {
        //update transaction info in passbook
    }
}
