package com.javatechie.solid.lsp.solution;

public interface SocialMedia {

    public   void chatWithFriend();

    public   void sendPhotosAndVideos();

}
