package com.javatechie.solid.lsp;

public class Whatsapp extends SocialMedia {
    public void chatWithFriend() {

    }

    public void publishPost(Object post) {
//Not applicable
    }

    public void sendPhotosAndVideos() {

    }

    public void groupVideoCall(String... users) {

    }
}
